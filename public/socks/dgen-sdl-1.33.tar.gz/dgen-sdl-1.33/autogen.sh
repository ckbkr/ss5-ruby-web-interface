#!/bin/sh

export AUTOCONF_VERSION=2.69
export AUTOMAKE_VERSION=1.11
autoreconf -fi
