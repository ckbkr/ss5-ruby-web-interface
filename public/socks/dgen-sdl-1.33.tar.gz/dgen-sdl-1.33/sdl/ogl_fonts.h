#ifndef OGL_FONTS_H_
#define OGL_FONTS_H_

#ifdef __cplusplus
#define OGL_FONTS_DECL_BEGIN__ extern "C" {
#define OGL_FONTS_DECL_END__ }
#else
#define OGL_FONTS_DECL_BEGIN__
#define OGL_FONTS_DECL_END__
#endif

OGL_FONTS_DECL_BEGIN__

extern unsigned char ogl_font_5x5[256][5][5];

OGL_FONTS_DECL_END__

#endif /* OGL_FONTS_H_ */
